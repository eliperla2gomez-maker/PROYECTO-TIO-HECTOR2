# server.py ejemplo
print('Servidor listo (falta tu api_key.txt)')